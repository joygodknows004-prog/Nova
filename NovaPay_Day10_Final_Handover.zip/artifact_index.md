# NovaPay Fraud Detection Artifact Index

## Final Deliverables

- NovaPay_Fraud_Report.pdf
- NovaPay_Fraud_Slides.pptx
- artifact_index.md

## Main Notebooks

- 01_kickoff_summary.md
- NovaPay_Week1_Day2_Data_Assessment.ipynb
- NovaPay_Week1_Day3_cleaning.ipynb
- 04_features_eda.ipynb
- 05_baseline_models.ipynb
- 06_advanced_models.ipynb
- 07_explainability.ipynb
- 08_api_pipeline.ipynb
- 09_monitoring.ipynb

## Key Data and Model Files

- cleaned_transactions.csv
- engineered_transactions.csv
- baseline_metrics.json
- advanced_model_experiments.csv
- advanced_metrics.json
- api/fraud_pipeline.joblib
- api/model_columns.joblib

## API and Deployment Files

- api/main.py
- api/requirements.txt
- Dockerfile

## Explainability and Monitoring Reports

- 07_explanation_template.md
- 09_data_drift_report.html
- 09_classification_performance_report.html
- 09_monitoring_summary.csv
- retraining_playbook.md

## Purpose

This artifact index supports final project handover by showing the main files created across the NovaPay fraud-detection project.
