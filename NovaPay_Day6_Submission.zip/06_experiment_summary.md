# NovaPay Fraud Detection Project

## Week 2 – Day 1: Advanced Modelling and Imbalance Handling

## Objective

The purpose of Day 6 was to improve fraud recall and model robustness using XGBoost, LightGBM and class-imbalance techniques.

## Baseline Reference

- Model: Logistic Regression
- Precision: 0.6347
- Recall: 0.8643
- F1-score: 0.7319
- ROC-AUC: 0.9455

## Advanced Experiments

- XGBoost with class-weight adjustment
- LightGBM with class-weight adjustment
- XGBoost with SMOTE
- LightGBM with random undersampling

## Strongest Advanced Result

- Model: LightGBM
- Imbalance method: Random undersampling
- Precision: 0.8308
- Recall: 0.8392
- F1-score: 0.8350
- ROC-AUC: 0.9425
- Recall difference from strongest baseline: -2.51 percentage points

## Performance Stability

Changing fraud prevalence can affect recall and precision.

NovaPay should monitor model performance across time periods and investigate sustained declines.

## Conclusion

The strongest advanced model should be carried forward to Day 7 for explainability and stakeholder review.
