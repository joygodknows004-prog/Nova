
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import Dict, Any
import pandas as pd
import joblib
import os

app = FastAPI(
    title="NovaPay Fraud Scoring API",
    description="Real-time fraud scoring service for NovaPay transactions",
    version="1.0"
)

MODEL_PATH = os.path.join(
    os.path.dirname(__file__),
    "fraud_pipeline.joblib"
)

COLUMNS_PATH = os.path.join(
    os.path.dirname(__file__),
    "model_columns.joblib"
)

model = joblib.load(MODEL_PATH)
model_columns = joblib.load(COLUMNS_PATH)


class TransactionRequest(BaseModel):
    transaction: Dict[str, Any]


@app.get("/")
def home():
    return {
        "message": "NovaPay Fraud Scoring API is running"
    }


@app.post("/score")
def score_transaction(request: TransactionRequest):
    transaction_data = request.transaction

    missing_columns = [
        column for column in model_columns
        if column not in transaction_data
    ]

    if missing_columns:
        raise HTTPException(
            status_code=400,
            detail={
                "error": "Missing required input fields",
                "missing_fields": missing_columns
            }
        )

    input_df = pd.DataFrame(
        [transaction_data]
    )

    input_df = input_df[model_columns]

    fraud_probability = model.predict_proba(
        input_df
    )[0][1]

    fraud_prediction = int(
        fraud_probability >= 0.5
    )

    decision = (
        "flag_for_review"
        if fraud_prediction == 1
        else "allow_transaction"
    )

    return {
        "fraud_prediction": fraud_prediction,
        "fraud_probability": round(
            float(fraud_probability),
            4
        ),
        "confidence_score_percent": round(
            float(fraud_probability) * 100,
            2
        ),
        "decision": decision
    }
